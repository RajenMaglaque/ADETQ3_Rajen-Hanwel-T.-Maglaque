﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ajen_quiz_two.Models;
using Microsoft.VisualBasic;

namespace ajen_quiz_two.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }
        
        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult About()
        {
            ViewData["My Information in Genshin impact"] = "";
            ViewData["Rank"] = "14";
            ViewData["Name"] = "Name: P5YM0N";
            ViewData["LineUp"] = "Fischl, Noelle, Xiangling And the Traveler.";
            ViewData["Reallife"] = "Rajen Maglaque";
            ViewData["Age"] = "20";

            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
